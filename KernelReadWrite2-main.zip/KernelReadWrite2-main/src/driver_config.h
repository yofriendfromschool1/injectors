#pragma once

#define DRIVER_NAME L"PaysonDriver"
#define DRIVER_DEVICE_NAME     L"\\Device\\PaysonDriver"
#define DRIVER_DOS_DEVICE_NAME L"\\DosDevices\\PaysonDriver"
#define DRIVER_DEVICE_PATH  L"\\\\.\\PaysonDriver"
#define DRIVER_DEVICE_TYPE 0x00000022
