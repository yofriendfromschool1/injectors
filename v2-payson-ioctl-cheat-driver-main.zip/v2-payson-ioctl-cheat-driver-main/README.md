# Payson IOCTL v2

This is my v2 IOCTL cheat driver. This is updated to have latest cr3 for EAC and draws way less detections than the old verison.
There is no write process memory as that draws detections but you can add it back.

# MUST HAVE THE WDK AND COMPATIBLE SDK VERSION INSTALLED TO BUILD WITHOUT ERRORS!

# Credits

Made By [Payson](https://github.com/paysonism)
